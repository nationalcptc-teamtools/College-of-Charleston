export interface TransactionBase {
  from?: string;
  gas?: number;
  gasPrice?: number;
  value?: number;
}
