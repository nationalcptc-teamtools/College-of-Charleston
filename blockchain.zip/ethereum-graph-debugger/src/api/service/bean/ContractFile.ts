export interface ContractFile {
  name: string
  code: string
  path: string
}
