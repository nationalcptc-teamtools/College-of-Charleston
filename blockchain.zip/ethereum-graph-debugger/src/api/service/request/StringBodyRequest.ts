export interface StringBodyRequest {
  request: string
}
