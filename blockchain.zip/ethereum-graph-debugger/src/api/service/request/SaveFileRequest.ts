export interface SaveFileRequest {
  path: string
  name: string
  content: string
}
