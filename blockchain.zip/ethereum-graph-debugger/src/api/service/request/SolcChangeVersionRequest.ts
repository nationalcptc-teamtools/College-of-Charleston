export interface SolcChangeVersionRequest {
  version: string
}
