export interface Opcode {
  name: string
  opcode: number
  parameters: number
}
