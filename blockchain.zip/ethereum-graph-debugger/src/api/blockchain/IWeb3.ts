export interface IWeb3 {
  getInstance(): any
}
