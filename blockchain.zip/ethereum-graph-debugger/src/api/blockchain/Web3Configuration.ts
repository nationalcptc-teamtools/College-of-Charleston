export class Web3Configuration {
  blockchainHost: string // url + port
  blockchainProtocol: string // http or https
  blockchainBasicAuthUsername: string
  blockchainBasicAuthPassword: string
}
