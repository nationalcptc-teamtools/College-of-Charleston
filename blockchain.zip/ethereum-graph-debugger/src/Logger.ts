import { Logger } from 'winston'

const logger = new Logger()

export { logger }
