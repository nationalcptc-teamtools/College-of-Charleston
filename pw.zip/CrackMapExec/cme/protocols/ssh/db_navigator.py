from cme.cmedb import DatabaseNavigator


class navigator(DatabaseNavigator):
    pass
